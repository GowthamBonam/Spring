package com.niit.userapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
