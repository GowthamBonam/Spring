package com.niit.userapi.controller;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.niit.userapi.model.User;
import com.niit.userapi.service.UserService;

@RestController
@RequestMapping("api/v1/")
public class UserController {
	
	private UserService userService;
	
	@Autowired
	public UserController(UserService userServie) {
		super();
		this.userService = userServie;
	}


	@PostMapping("/user")
	public ResponseEntity<?> addUser(@RequestBody User user){
		
		userService.addUser(user);
		
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@GetMapping("/user")
	public ResponseEntity<?> getAllUser(){
		
		return new ResponseEntity<>(userService.getAllUser(),HttpStatus.OK);
	}
	
	@DeleteMapping("/user/{email}")
	public ResponseEntity<?> deleteUser(@PathVariable("email") String email){
		userService.deleteUser(email);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	@PutMapping("/user")
	public ResponseEntity<?> updateUser(@RequestBody User user){
		
		return new ResponseEntity<>(userService.updateUser(user),HttpStatus.CREATED);
	}

}
