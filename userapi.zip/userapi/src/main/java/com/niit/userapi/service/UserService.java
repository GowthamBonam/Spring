package com.niit.userapi.service;

import java.util.List;

import com.niit.userapi.model.User;

public interface UserService {
	
	void addUser(User user);
	List<User> getAllUser();
	void deleteUser(String email);
	User updateUser(User user);

}
