package com.niit.userapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.userapi.dao.UserRepository;
import com.niit.userapi.model.User;

@Service
public class UserServiceImpl implements UserService{
	
	UserRepository userRepository;

	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
	
		this.userRepository = userRepository;
	}

	@Override
	public void addUser(User user) {
		userRepository.save(user);
		
	}

	@Override
	public List<User> getAllUser() {
		
		return userRepository.findAll();
	}


	@Override
	public User updateUser(User user) {
	User userData=userRepository.findById(user.getEmail()).orElse(null);
	if(userData!=null) {
		userData.setEmail(user.getEmail());
		userData.setPassword(user.getPassword());
	}	
		return userRepository.saveAndFlush(userData); //removes old data and updates new data
	}

	@Override
	public void deleteUser(String email) {
	User user=userRepository.findById(email).orElse(null);	
		if(user!=null) {
			userRepository.delete(user);
		}

	}

	
}
