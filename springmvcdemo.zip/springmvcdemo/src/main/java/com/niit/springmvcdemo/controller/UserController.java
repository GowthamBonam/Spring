package com.niit.springmvcdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController {
	
	@RequestMapping("/hello/{name}")
	public String show(@PathVariable("name") String name, Model model) {

	model.addAttribute("message", "hello "+name);  // takes in key(message) value(hello) pair
	//handler method  returns data acc to return type of method
		
		return "index";
		
	}
	
	@RequestMapping("/request")
	@ResponseBody
	public String sendResponse() {
		
		return "hello";
		
	}

}

