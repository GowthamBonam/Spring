var fs= require('fs');
fs.appendFile('my file.txt','new added text ',function(err) {

    if(err) throw err;
    console.log('updated');
});



