const { captureRejectionSymbol } = require('events');
var url = require('url');

//parse()
var q = url.parse(addr , true);
//url properties
console.log(q.host);
console.log(q.pathname);
var querydata = q.query;
console.log(querydata.month);
