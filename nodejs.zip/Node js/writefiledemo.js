var fs = require('fs');
fs.writeFile('myfile.txt' , 'Hello world' , function (err) {
if(err) throw err;
console.log("writing in file is succes");

});